class aluno:
    def __init__(self, lista_turma, matricula, turma, nome):
        self.matricula = matricula
        self.turma = turma[0]
        self.nome = nome
        if turma[1] == 0:
            self.materias = lista_turma[turma[0]]
        else:
            self.materias = turma[2]

    def __str__(self):
        return f'{self.nome}'
    
def criarNovaTurma(lista_turmas, lista_materias_existente):
    print('-'*40)
    resp = verificarResp('Tem certeza que deseja criar uma nova turma? (S/N)', [True, False])
    if resp:
        while True:
            try:
                serie = int(input('Digite a serie da nova turma que sera adicionada(lembrando que o sistema só ira aceitar series do fundamental II ou ensino medio): '))
                if len(str(serie)) != 1:
                    input('Resposta não reconhecida, coloque somente um caractere\nPressione ENTER para tentar novamente: ')
                    continue
                if serie == 4 or serie == 5 or serie > 9:
                    input('Serie não existente, o sistema só aceita serie do fundamental II ou ensino medio\nPressione ENTER para tentar novamente: ')
                    continue
            except:
                input('Resposta não reconhecida, só é permitido numeros\nPressione ENTER para tentar novamente: ')
                continue
            letra_id = input('Me informe a letra identificadora da turma: ')
            if not(letra_id.replace(' ', '').isalpha()):
                input('Resposta não reconhecida, o sistema só aceita letras\nPressione ENTER para tentar novamente')
                continue
            turma = str(serie)+'.'+letra_id.upper()
            if not(turma in lista_turmas):
                break
            else:
                if not(verificarResp('Essa turma ja existe\nGostaria de ainda registrar uma nova turma? (S/N)', [True, False])):
                    return False, None, None
        materias_escolhidas = []
        while True:
            if not(materias_escolhidas):
                n_escolher = False
            else:
                n_escolher = True
            materia_escolhida = verificarResp('Escolha a materia que deseja para turma que sera criada: ', [False, False, lista_materias_existente, n_escolher])
            print(materia_escolhida)
            if not(materia_escolhida):
                if verificarResp('Gostaria de recomeçar e colocar mais uma materia? (S/N)', [True, False]):
                    continue
                if verificarResp('Gostaria de terminar de colocar materias e adicionar a nova turma? (S/N)', [True, False]):
                    return True, turma, materias_escolhidas
            if materia_escolhida in materias_escolhidas:
                input('Materia ja esta registrada na lista de materias da turma\nPressione ENTER para tentar novamente: ')
                continue 
            materias_escolhidas.append(materia_escolhida)
            print(materias_escolhidas)
            print(len(materias_escolhidas))
            if len(materias_escolhidas) < len(lista_materias_existente) and verificarResp('Gostaria de adicionar mais uma materias a turma? (S/N)', [True, False]):
                input('Pressione ENTER para adicionar mais uma materia: ')
            else:
                input ('Não existe mais materias para registrar!!!\nPressione ENTER para registrar a turma e voltar ao menu: ')       
                return True, turma, materias_escolhidas
    else:
        input('Pressione ENTER para voltar ao menu: ')
        return False, None, None

def imprimirTabelaTurmas(lista_turmas):
        lista_turmas_brutos = [turma.split('.') for turma in lista_turmas]
        lista_series_separadas = [[] for x in range(7)]
        for turma in lista_turmas_brutos:
            serie = int(turma[0])
            if 1 <= serie <= 3:
                lista_series_separadas[serie-4].append(turma)
            else:
                lista_series_separadas[serie-6].append(turma)
        lista_series_organizadas = []
        for series in lista_series_separadas:
            series_organizar = sorted(series, key=lambda elem: elem[1])
            lista_series_organizadas.append(series_organizar)
        print('Turmas ja registradas:')
        for series_separadas in lista_series_separadas:
            for turma_imprimida in series_separadas:
                serie = turma_imprimida[0]
                letra = turma_imprimida[1]
                print(serie+'.'+letra)
                
        input('-----------------------------------------\nDe enter para voltar ao menu ')

def criarTabelaDeMedias(lista_turmas, lista_geral_alunos):
        while True:
            try:
                serie = int(input('Informe a serie da turma: '))
                if serie < 1 or serie > 9 or serie == 5 or serie == 4:
                    print('Serie inexistente, coloque outra')
                    continue
                letra = input('Informe a letra identificadora da turma: ')
                if not(letra.isalpha()):
                    print('A entrada digitada não é uma letra')
                    continue
                break
            except:
                print('Serie invalida coloque outra serie')
        turma_procurada = str(serie)+'.'+letra.upper()
        #Analizando se a turma existe
        if turma_procurada in lista_turmas:
            #Se existir cria lista com os alunos dessa turma filtrando da lista geral
            lista_alunos_filtrados = []
            print('-'*40)
            print(turma_procurada)
            for aluno_analizar in lista_geral_alunos.values():
                if aluno_analizar.turma == turma_procurada:
                    lista_alunos_filtrados.append(aluno_analizar)
            materias = lista_turmas[turma_procurada]
            materia_escolhida = verificarResp('Escolha a materia que deseja ver a media dos alunos:', [False, False, materias, False])
            for aluno_escolhido in lista_alunos_filtrados:
                nome_aluno = aluno_escolhido.nome
                notas_aluno = aluno_escolhido.materias[materia_escolhida]
                print(f'Nome: {nome_aluno:<20} media: {(sum(notas_aluno) / 4):.2f}')
            input(('-'*40)+'\n'+'De enter para voltar ao menu:\n')
        else:
            input('Turma não encontrada\nDe enter para voltar para o menu: ')

def registrarNovoAluno(lista_turmas, lista_geral_alunos):
    while True:
        try:
            aluno_serie = int(input('Coloque a serie do aluno: '))
            if aluno_serie < 1 or aluno_serie > 9 or aluno_serie == 4 or aluno_serie == 5:
                print('Coloque uma serie que esteja entre 6° e 3° ano')
                continue
            break
        except:
            input('A serie deve ser um numero entre o 6° e 3° ano\nDe enter para voltar: ')
    while True:
        aluno_letra = input('Coloque a letra que representa a turma: ')
        if not(aluno_letra.isalpha()) or len(aluno_letra) != 1:
            print('Valor invalido!!!, só é permitido uma unica letra')
            continue
        break
    aluno_turma = f'{str(aluno_serie)}.{aluno_letra.upper()}'
    if not(aluno_turma in lista_turmas):
        print('Essa turma não existe, caso ainda queira registrar pode se criar uma nova serie oub colocar em outra serie ja existente')
        input('De enter para voltar: ')
    else: 
        while True:
            try:
                aluno_matricula = input('Fale a matricula do novo aluno: ')
                int(aluno_matricula)
                if len(aluno_matricula) != 5:
                    input('numero de digitos diferente do padrão, coloque 5 digitos\nDe enter pra voltar: ')
                    continue
                if aluno_matricula in lista_geral_alunos:
                    input('Matricula ja existente, coloque outra matricula\nDe enter para voltar: ')
                    continue 
                break
            except:
                input('A matricula deve ser composta somente por numeros inteiros\nDe enter para voltar: ')
        aluno_nome = input('Fale o nome do novo aluno: ')
        lista_geral_alunos[aluno_matricula] = aluno(lista_turmas, aluno_matricula, (aluno_turma, 0), aluno_nome)

def imprimirTodosAlunos(lista_geral_alunos):
    print(('-'*40)+'\nTabela de alunos registrados:')
    for matricula_imprimir, aluno_imprimir in lista_geral_alunos.items():
        print(f'Matricula: {matricula_imprimir} | nome: {aluno_imprimir.nome:<20} | turma: {aluno_imprimir.turma}')
    print('-'*40)   
    input('De enter para voltar: ')

def mudarNota(lista_geral_alunos):
    while True:
        lista_modificados = []
        filtro_matricula = input('Me informe a matricula do aluno: ')
        if filtro_matricula in lista_geral_alunos:
            materias_aluno = lista_geral_alunos[filtro_matricula].materias
            lista_materias = [mat for mat in materias_aluno]
            materia_escolhida = verificarResp('Escolha a materia da qual você deseja ver a nota do aluno:', [False, False, lista_materias, True])
            if materia_escolhida:
                cancelar_mudanca = False
                notas = materias_aluno[materia_escolhida]
            else:
                cancelar_mudanca = True
            if not(cancelar_mudanca):
                notas_imprimir = [f'nota: {float(not_imp)}' for not_imp in notas]  
                nota_escolhida = notas.index(float(verificarResp('EScolha a nota da qual sera modificada a nota:', [False, False, notas_imprimir, False]).split(': ')[1]))
                while True:
                    try:
                        nova_nota = float(input('Informe qual sera a nova nota: '))
                    except:
                        input('Nota digitada não é um valor numerico, coloque um valor numerico: ')
                        continue
                    if nova_nota < 0 or nova_nota > 10:
                        input('Nota digitada excede os padrões o valor deve estar entre 0 e 10\nDe enter para tenter novamente: ')
                        continue
                    break
                notas[nota_escolhida] = nova_nota
                lista_modificados.append([notas, nota_escolhida, nova_nota])
                if verificarResp('Gostaria de modificar mais uma nota? (S/N)\n', [True, True]):
                    return False, lista_modificados 
            else:
                input('Pressione ENTER para voltar ao menu:')
                return True, None
        else:
            cancelar_mudanca = verificarResp('Matricula não encontrada, gostaria de tentar novamente? (S/N)', [True, True])
            if cancelar_mudanca:
                return True, None

def resgatarDados():
    import os
    numero_endereco = 0
    diretorio = os.path.dirname(os.path.abspath(__file__))
    while True:
        nome_arquivo = f'registros_gerenciador_alunos_{numero_endereco}.txt' 
        caminho = os.path.join(diretorio, nome_arquivo)
        if os.path.exists(caminho):
            with open(caminho, 'r') as arquivo:
                conferir = arquivo.readline()
            if conferir.strip() == '#SYS_ALUNO_V1':
                analizar_arquivo = True
                break 
        else:
            with open(caminho, 'w') as arquivo:
                arquivo.write('#SYS_ALUNO_V1\n')
                analizar_arquivo = False
            break
        numero_endereco += 1

    lista_geral_alunos = {}
    lista_turmas = {}
    lista_materias_existente = []
    if analizar_arquivo:  
        nome_arquivo = f'registros_gerenciador_alunos_{numero_endereco}.txt' 
        caminho = os.path.join(diretorio, nome_arquivo)                  
        with open (caminho, 'r') as arquivo:
            texto_registro = arquivo.readlines()
        while texto_registro:
            dado = texto_registro.pop(0).strip()
            if dado == 'TURMAS':
                dado = texto_registro.pop(0).strip()
                if dado == '{':
                    while True:
                        dado = texto_registro.pop(0).strip()
                        if dado == '}':
                            break
                        turma = dado.strip()
                        materias_turma = {}
                        dado = texto_registro.pop(0).strip()
                        if dado == '{':
                            while True:
                                dado = texto_registro.pop(0).strip()
                                if dado == '}':
                                    break
                                else:
                                    materias_turma.update({dado: [0, 0, 0, 0]})
                            lista_turmas[turma] = materias_turma
                        else:
                            pass#colocar mansagem
                else:
                    pass#colocar mensagem 
            
            elif dado == 'ALUNOS':
                dado = texto_registro.pop(0).strip()
                if dado == '{':
                    while True:
                        if texto_registro[0].strip() == '}':
                            del texto_registro[0]
                            break
                        while True:
                            dado = texto_registro.pop(0).strip()
                            if dado == '}':
                                break
                            if dado == 'Dados_aluno_para_registro':
                                dado = texto_registro.pop(0).strip()
                                if dado.strip() == '{':
                                    matricula = texto_registro.pop(0).strip()
                                    nome = texto_registro.pop(0).strip()
                                    turma_aluno = texto_registro.pop(0).strip()
                                    dado = texto_registro.pop(0).strip()
                                    if dado == 'Materias_aluno':
                                        dado = texto_registro.pop(0).strip()
                                        if dado == '{':
                                            lista_materias_aluno = {}
                                            while True:
                                                dado = texto_registro.pop(0).strip()
                                                if dado == '}':
                                                    break 
                                                materia = dado
                                                lista_notas = []
                                                dado = texto_registro.pop(0).strip()
                                                if dado == '{':
                                                    for i in range(4):
                                                        lista_notas.append(float(texto_registro.pop(0).strip()))
                                                    lista_materias_aluno[materia] = lista_notas
                                                    del texto_registro[0]
                                            lista_geral_alunos[matricula] = aluno(lista_turmas, matricula, (turma_aluno, 1, lista_materias_aluno), nome)                                
                
            elif dado == 'MATERIAS_EXISTENTES':
                dado = texto_registro.pop(0).strip()
                if dado == '{':
                    while True:
                        dado = texto_registro.pop(0).strip()
                        if dado.strip() == '}':
                            break
                        lista_materias_existente.append(dado)
        
    return lista_geral_alunos, lista_turmas, lista_materias_existente, numero_endereco

def salvarDados(lista_turmas, lista_geral_alunos, lista_materias_existente, numero_endereco):
    import os
    texto = []
    texto.append('#SYS_ALUNO_V1\n')
    texto.append('TURMAS\n{\n')
    for turma, materias_turma in lista_turmas.items():
        texto.append(f'{turma}\n'+'{\n')
        for materia_turma in materias_turma:
            texto.append(f'{materia_turma}\n')
        texto.append('}\n')
    texto.append('}\n')
    texto.append('ALUNOS\n{\n')
    for aluno_registrar in lista_geral_alunos.values():
        texto.append('Dados_aluno_para_registro\n{\n')
        texto.append(f'{aluno_registrar.matricula}\n{aluno_registrar.nome}\n{aluno_registrar.turma}\n')
        texto.append('Materias_aluno\n{\n')
        for materia, notas_registrar in aluno_registrar.materias.items():
            texto.append(materia+'\n{\n'+f'{notas_registrar[0]}\n{notas_registrar[1]}\n{notas_registrar[2]}\n{notas_registrar[3]}'+'\n}\n')
        texto.append('}\n')
        texto.append('}\n')
    texto.append('}\n')
    texto.append('MATERIAS_EXISTENTES\n{\n')
    for materia_existente in lista_materias_existente:
        texto.append(f'{materia_existente}'+'\n')
    texto.append('}\n')
    nome_arquivo = f'registros_gerenciador_alunos_{numero_endereco}.txt' 
    diretorio = os.path.dirname(os.path.abspath(__file__))
    caminho = os.path.join(diretorio, nome_arquivo)
    with open(caminho, 'w') as arquivo:
        arquivo.write(''.join(texto))
    input('De enter para fechar o sistema: ')

def registrarNovaMateria(lista_materias_existente):
    while True:
        resp = verificarResp('Deseja prosseguir com o registro de uma nova materia? (S/N)', [True, False])
        if resp:
            if lista_materias_existente:
                print('Materias já registradas:\n'+'-'*40)
                for materia_imp in lista_materias_existente:
                    print(materia_imp.capitalize())
                print('-'*40+'\n')
            while True:
                materia = input('Digite o nome da materia que deseja ser registrar: ')
                if materia.replace(' ', '').isalpha():
                    if len(materia.strip()) <= 25:
                        break
                    else:
                        input('Nome de materia muito grande, coloque um nome de materia que possua até 25 caracteres\nPressione ENTER para tentar novamente:  ')
                else:
                    input('Não é permitido numeros ou simbolos, coloque somente letras\nPressione ENTER para tentar novamente: ')
            materia = ajeitar(materia)
            if materia in lista_materias_existente:
                voltar_menu = verificarResp('Materia ja existente!!!\nGostaria de tentar novamente uma materia, mas com um nome diferente? (S/N)', [True, True])
                if voltar_menu:
                    input('Pressione ENTER para voltar ao menu: ') 
                    return None, False
            else:
                input('Materia Registrada!!!\nPressione ENTER para voltar ao menu: ')
                return materia, True
        else:
            input('Pressione ENTER para voltar ao menu')
            return None, False


def verificarResp(mensagem, termo):
    generico = termo[0]
    inverter = termo[1]
    if inverter:
        cond_True = False
        cond_False = True
    else:
        cond_True = True
        cond_False = False
    if generico:
        filtro1 = mensagem.split('?')[1].split('/')[0].split('(')[1]
        filtro2 = mensagem.split('?')[1].split('/')[1].split(')')[0]
        while True:
            resp = input(mensagem+'\n')
            if ajeitar(resp) == ajeitar(filtro1):
                return cond_True
            elif ajeitar(resp) == ajeitar(filtro2):
                return cond_False
            else:
                input(f'Resposta não reconhecida, coloque "{filtro1}" ou "{filtro2}"\nPressinoe ENTER para escolher novamente: ')
    else:
        opcoes = termo[2]
        n_escolher = termo[3]
        while True:
            print(mensagem+'\n'+'-'*40)
            for indice, opcao in enumerate(opcoes):
                print(f'{opcao:<20} : {indice+1}')
            if n_escolher:
                print(f'{"Não escolher nenhuma das opções":<20} : {len(opcoes)+1}')
            try:
                resp = int(input(('-'*40)+'\nDigite o numero a frente da escolha desejada: '))
            except:
                input('Resposta colocada não é um numero, coloque o numero a frente da escolha desejada\nPressione ENTER para tenter novamente: ')
                continue
            if n_escolher:
                if resp-1 < 0 or resp-1 > len(opcoes):
                    input(f'resposta não reconhecida, coloque uma das opções entre 1 e {len(opcoes)+1}\nPressione ENTER para tentar novamete: ')
                    continue
            else:
                if resp-1 < 0 or resp-1 > len(opcoes)-1:
                    input(f'resposta não reconhecida, coloque uma das opções entre 1 e {len(opcoes)}\nPressione ENTER para tentar novamete: ')
                    continue
            if resp-1 < len(opcoes):
                escolha = opcoes[resp-1]
            else:
                escolha = None
            return escolha

def ajeitar(resp):
    return resp.lower().strip()