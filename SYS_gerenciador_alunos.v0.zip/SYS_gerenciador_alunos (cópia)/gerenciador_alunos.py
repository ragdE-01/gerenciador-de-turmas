from mod_gerenciador_alunos import aluno, criarNovaTurma, imprimirTabelaTurmas, criarTabelaDeMedias, registrarNovoAluno, imprimirTodosAlunos, mudarNota, resgatarDados, salvarDados, registrarNovaMateria
lista_geral_alunos, lista_turmas, lista_materias_existente, numero_endereco = resgatarDados()
while True:
    print('-'*40)
    print('Ver todas as turmas registradas: 1')
    print('Criar nova turma: 2')
    print('Criar novo aluno: 3')
    print('Mostrar tabela de aprovação de turma: 4')
    print('Ver todos os alunos registrados: 5')
    print('Alterar nota de aluno: 6')
    print('Registrar nova materia: 7')
    print('Salvar e sair: 8')
    resp = input('Informe o numero a frente da opção que deseja: ')
    if resp.lower().strip() == '1':
        imprimirTabelaTurmas(lista_turmas)
    elif resp.lower().strip() == '2':
        if lista_materias_existente:
            criar, turma_registrar, materias_turma = criarNovaTurma(lista_turmas, lista_materias_existente)
            if criar:
                lista_turmas[turma_registrar] = materias_turma
        else:
            input('No momento não a nenhuma materia registrada, só é permitido o registro de novas turmas com no minimo uma materia\nDe enter e volte ao menu, após o regisro de alguma materia estara liberado o registro de novas turmas: ')
    elif resp.lower().strip() == '3':
        registrarNovoAluno(lista_turmas, lista_geral_alunos)
    elif resp.lower().strip() == '4':
        criarTabelaDeMedias(lista_turmas, lista_geral_alunos)
    elif resp.lower().strip() == '5':
        imprimirTodosAlunos(lista_geral_alunos)
    elif resp.lower().strip() == '6':
        cancelar_mudanca, lista_dados_mudanca = mudarNota(lista_geral_alunos)
        if not(cancelar_mudanca):
            for notas, nota_escolhida, nova_nota in lista_dados_mudanca:
                notas[nota_escolhida] = nova_nota
        input(('-'*40)+'\nDe enter para voltar ao menu: ')
    elif resp.strip().lower() == '7':
        nova_materia, registrar = registrarNovaMateria(lista_materias_existente)
        if registrar:
            input('Registrou')
            lista_materias_existente.append(nova_materia.lower())
    elif resp.lower().strip() == '8':
        salvarDados(lista_turmas, lista_geral_alunos, lista_materias_existente, numero_endereco)
        exit()
    else: 
        input('Opção não reconhecida\nDe enter para voltar ao menu: ')
        